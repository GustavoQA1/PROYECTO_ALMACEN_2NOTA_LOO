﻿using Datos;
using System;
using System.Collections.Generic;
using System.Text;

namespace Modelos
{
    public interface IDataEntity
    {
        public data Data { get; set; }
        public List<Parametros> parametros { get; set; }
    }
}
