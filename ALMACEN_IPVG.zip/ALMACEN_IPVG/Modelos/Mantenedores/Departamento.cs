﻿using System;
using Datos;

namespace Modelos.Mantenedores
{
    public class Departamento : IDataEntity
    {
        public int id_departamento{ get; set; }
        public string nombre_departamento { get; set; }
        public data Data { get; set; }
        public List<Parametros> parametros { get; set; }

        public Departamento()
        {
            Data = new data();
            parametros = new List<Parametros>();
        }
    }
}