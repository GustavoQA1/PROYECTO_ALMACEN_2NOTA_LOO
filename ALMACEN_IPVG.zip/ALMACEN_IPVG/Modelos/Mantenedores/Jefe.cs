﻿using System;
using Datos;

namespace Modelos.Mantenedores
{
    public class Jefe : IDataEntity
    {
        public int rut_jefe { get; set; }
        public string nombre_jefe { get; set; }
        public string apellido_jefe { get; set; }
        public data Data { get; set; }
        public List<Parametros> parametros { get; set; }

        public Jefe()
        {
            Data = new data();
            parametros = new List<Parametros>();
        }
    }
}