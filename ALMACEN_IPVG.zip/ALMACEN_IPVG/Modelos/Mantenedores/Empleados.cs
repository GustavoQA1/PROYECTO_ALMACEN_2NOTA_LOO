﻿using System;
using Datos;

namespace Modelos.Mantenedores
{
    public class Empleados : IDataEntity
    {
        public int rut_empleado { get; set; }
        public string nombre_empleado { get; set; }
        public string apellido_empleado { get; set; }

        public string direccion { get; set; }

        public int telefono { get; set; }
        public data Data { get; set; }
        public List<Parametros> parametros { get; set; }

        public Empleados()
        {
            Data = new data();
            parametros = new List<Parametros>();
        }
    }
}