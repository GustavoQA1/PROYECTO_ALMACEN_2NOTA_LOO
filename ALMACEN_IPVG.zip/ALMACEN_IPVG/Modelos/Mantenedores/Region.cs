﻿using System;
using Datos;

namespace Modelos.Mantenedores
{
    public class Region: IDataEntity
    {
        public int id_region { get; set; }
        public string nombre_region { get; set; }
        public data Data { get; set; }
        public List<Parametros> parametros { get; set; }

        public Region()
        {
            Data = new data();
            parametros = new List<Parametros>();
        }
    }
}