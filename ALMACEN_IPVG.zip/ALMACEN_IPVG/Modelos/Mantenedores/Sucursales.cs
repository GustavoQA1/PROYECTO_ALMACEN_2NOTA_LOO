﻿using System;
using Datos;

namespace Modelos.Mantenedores
{
    public class Sucursales : IDataEntity
    {
        public int id_sucursal { get; set; }
        public string ciudad{ get; set; }
        public string direccion{ get; set; }
        public int telefono { get; set; }

        public data Data { get; set; }
        public List<Parametros> parametros { get; set; }

        public Sucursales()
        {
            Data = new data();
            parametros = new List<Parametros>();
        }
    }
}