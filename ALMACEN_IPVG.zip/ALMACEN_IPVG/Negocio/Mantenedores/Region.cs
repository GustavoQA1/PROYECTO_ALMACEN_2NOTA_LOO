﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Modelos;
using Modelos.Mantenedores;

namespace Negocio.Mantenedores
{
    public class RegionBL : ICrud<Region>
    {

        public ResponseExec Create(Region o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.id_region));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.nombre_region));
                //o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                o.Data.ejecutarSP("sp_region", o.parametros);
                res.mensaje = "Ingreso Correcto a Regiones";
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }
        }

        public ResponseExec Delete(Region o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.id_region));
                o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                res.mensaje = o.Data.ejecutarSP("SP_ELIMINAR_REGIONES", o.parametros);
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }

        }

        public Region GetById(Region o)
        {
            Region region = new Region();
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.id_region));
                DataTable dt = o.Data.listadoSP("SP_CARGA_REGIONES", o.parametros);
                if (dt.Rows.Count > 0)
                {
                    region.id_region = int.Parse(dt.Rows[0].ItemArray[0].ToString());
                    region.nombre_region = dt.Rows[0].ItemArray[1].ToString();
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return region;
        }

        public List<Region> GetQuery(Region o)
        {
            List<Region> region = new List<Region>();
            try
            {
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.nombre_region));
                DataTable dt = o.Data.listadoSP("SP_BUSCA_REGIONES", o.parametros);
                return convertToList(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return region;
        }


        public List<Region> Get(Region o)
        {
            List<Region> region = new List<Region>();
            try
            {
                DataTable dt = o.Data.queryData("select * from region");
                return convertToList(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return region;
        }

        public ResponseExec Update(Region o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.id_region));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.nombre_region));
                o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                res.mensaje = o.Data.ejecutarSP("SP_ACTUALIZAR_REGIONES", o.parametros);
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }
        }

        public List<Region> convertToList(DataTable dt)
        {
            List<Region> listado = new List<Region>();

            foreach (DataRow item in dt.Rows)
            {
                Region o = new Region();
                o.id_region = int.Parse(item.ItemArray[0].ToString());
                o.nombre_region = item.ItemArray[1].ToString();
                listado.Add(o);
            }

            return listado;
        }

    }
}