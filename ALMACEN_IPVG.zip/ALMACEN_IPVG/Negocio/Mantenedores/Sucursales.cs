﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Modelos;
using Modelos.Mantenedores;

namespace Negocio.Mantenedores
{
    public class SucursalesBL : ICrud<Sucursales>
    {

        public ResponseExec Create(Sucursales o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.id_sucursal));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.ciudad));
                o.parametros.Add(new Datos.Parametros("@DIRECCION", o.direccion));
                o.parametros.Add(new Datos.Parametros("@TELEFONO", o.telefono));
                //o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                o.Data.ejecutarSP("sp_sucursales", o.parametros);
                res.mensaje = "Ingreso Correcto a Sucursales";
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }
        }

        public ResponseExec Delete(Sucursales o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.id_sucursal));
                o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                res.mensaje = o.Data.ejecutarSP("SP_ELIMINAR_SUCURSALES", o.parametros);
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }

        }

        public Sucursales GetById(Sucursales o)
        {
            Sucursales sucursales = new Sucursales();
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.id_sucursal));
                DataTable dt = o.Data.listadoSP("SP_CARGA_SUCURSALES", o.parametros);
                if (dt.Rows.Count > 0)
                {
                    sucursales.id_sucursal = int.Parse(dt.Rows[0].ItemArray[0].ToString());
                    sucursales.ciudad = dt.Rows[0].ItemArray[1].ToString();
                    sucursales.direccion = dt.Rows[0].ItemArray[2].ToString();
                    sucursales.telefono = int.Parse(dt.Rows[3].ItemArray[0].ToString());
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return sucursales;
        }

        public List<Sucursales> GetQuery(Sucursales o)
        {
            List<Sucursales> sucursales = new List<Sucursales>();
            try
            {
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.ciudad));
                DataTable dt = o.Data.listadoSP("SP_BUSCA_SUCURSALES", o.parametros);
                return convertToList(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return sucursales;
        }


        public List<Sucursales> Get(Sucursales o)
        {
            List<Sucursales> sucursales = new List<Sucursales>();
            try
            {
                DataTable dt = o.Data.queryData("select * from sucursales");
                return convertToList(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return sucursales;
        }

        public ResponseExec Update(Sucursales o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.id_sucursal));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.ciudad));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.direccion));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.telefono));
                o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                res.mensaje = o.Data.ejecutarSP("SP_ACTUALIZAR_SUCURSALES", o.parametros);
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }
        }

        public List<Sucursales> convertToList(DataTable dt)
        {
            List<Sucursales> listado = new List<Sucursales>();

            foreach (DataRow item in dt.Rows)
            {
                Sucursales o = new Sucursales();
                o.id_sucursal = int.Parse(item.ItemArray[0].ToString());
                o.ciudad = item.ItemArray[1].ToString();
                o.direccion = item.ItemArray[2].ToString();
                o.telefono = int.Parse(item.ItemArray[3].ToString());
                listado.Add(o);
            }

            return listado;
        }

    }
}