﻿using System.Data;
using System.Linq;
using Modelos;
using Modelos.Mantenedores;

namespace Negocio.Mantenedores
{
    public class JefeBL : ICrud<Jefe>
    {

        public ResponseExec Create(Jefe o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.rut_jefe));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.nombre_jefe));
                o.parametros.Add(new Datos.Parametros("@APELLIDO", o.apellido_jefe));
             
                //o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                o.Data.ejecutarSP("sp_jefe", o.parametros);
                res.mensaje = "Ingreso Correcto a los Jefes";
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }
        }

        public ResponseExec Delete(Jefe o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.rut_jefe));
                o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                res.mensaje = o.Data.ejecutarSP("SP_ELIMINAR_JEFE", o.parametros);
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }

        }

        public Jefe GetById(Jefe o)
        {
            Jefe jefe = new Jefe();
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.rut_jefe));
                DataTable dt = o.Data.listadoSP("SP_CARGA_JEFE", o.parametros);
                if (dt.Rows.Count > 0)
                {
                    jefe.rut_jefe = int.Parse(dt.Rows[0].ItemArray[0].ToString());
                    jefe.nombre_jefe = dt.Rows[0].ItemArray[1].ToString();
                    jefe.apellido_jefe = dt.Rows[0].ItemArray[2].ToString();
        
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jefe;
        }

        public List<Jefe> GetQuery(Jefe o)
        {
            List<Jefe> jefe = new List<Jefe>();
            try
            {
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.nombre_jefe));
                o.parametros.Add(new Datos.Parametros("@APELLIDO", o.apellido_jefe));
                DataTable dt = o.Data.listadoSP("SP_BUSCA_JEFES", o.parametros);
                return convertToList(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jefe;
        }


        public List<Jefe> Get(Jefe o)
        {
            List<Jefe> jefe = new List<Jefe>();
            try
            {
                DataTable dt = o.Data.queryData("select * from jefe");
                return convertToList(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jefe;
        }

        public ResponseExec Update(Jefe o)
        {
            ResponseExec res = new ResponseExec();
            res.mensaje = "";
            try
            {
                o.parametros.Add(new Datos.Parametros("@CODIGO", o.rut_jefe));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.nombre_jefe));
                o.parametros.Add(new Datos.Parametros("@NOMBRE", o.apellido_jefe));
              
                o.parametros.Add(new Datos.Parametros("@MENSAJE", "", SqlDbType.VarChar, ParameterDirection.Output, 100));
                res.mensaje = o.Data.ejecutarSP("SP_ACTUALIZAR_JEFES", o.parametros);
                return res;
            }
            catch (Exception ex)
            {
                res.error = true;
                res.mensaje = ex.Message;
                return res;
            }
        }

        public List<Jefe> convertToList(DataTable dt)
        {
            List<Jefe> listado = new List<Jefe>();

            foreach (DataRow item in dt.Rows)
            {
                Jefe o = new Jefe();
                o.rut_jefe = int.Parse(item.ItemArray[0].ToString());
                o.nombre_jefe = item.ItemArray[1].ToString();
                o.apellido_jefe = item.ItemArray[2].ToString();
         

                listado.Add(o);
            }

            return listado;
        }

    }
}