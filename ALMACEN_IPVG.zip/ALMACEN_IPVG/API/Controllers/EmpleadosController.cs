﻿using System;
using System.Reflection;
using API.Helper;
using Microsoft.AspNetCore.Mvc;
using Modelos.Mantenedores;
using Negocio.Mantenedores;

namespace API.Controllers
{
    [ApiController]
    public class EmpleadosController : ControllerBase
    {
        EmpleadosBL empleadosBL = new EmpleadosBL();
        Empleados empleados = new Empleados();
        ErrorResponse error;

        [HttpPost]
        [Route("v1/empleados/Create")]
        public ActionResult Create(EmpleadosDTO o)
        {
            try
            {
                empleados.rut_empleado = o.rut_empleado;
                empleados.nombre_empleado = o.nombre_empleado;
                empleados.apellido_empleado = o.apellido_empleado;
                empleados.direccion = o.direccion;
                empleados.telefono = o.telefono;
                return Ok(empleadosBL.Create(empleados));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/empleados/Get")]
        public ActionResult Get()
        {
            try
            {
                return Ok(convertList(empleadosBL.Get(empleados)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpPost]
        [Route("v1/empleados/GetQuery")]
        public ActionResult GetQuery(string nombre, string apellido)
        {
            try
            {
                empleados.nombre_empleado = nombre;
                empleados.apellido_empleado = apellido;
                return Ok(convertList(empleadosBL.GetQuery(empleados)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/empleados/GetById")]
        public ActionResult GetById(int id)
        {
            try
            {
                empleados.rut_empleado = id;
                empleados = empleadosBL.GetById(empleados);
                if (empleados != null)
                    return Ok(convert(empleados));
                else
                    return StatusCode(404, empleados);
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }
        [HttpPut]
        [Route("v1/empleados/Update")]
        public ActionResult Update(EmpleadosDTO o)
        {
            try
            {
                empleados.rut_empleado = o.rut_empleado;
                empleados.nombre_empleado = o.nombre_empleado;
                empleados.apellido_empleado = o.apellido_empleado;
                empleados.direccion = o.direccion;
                empleados.telefono = o.telefono;
                return Ok(empleadosBL.Update(empleados));

               
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpDelete]
        [Route("v1/empleados/Delete")]
        public ActionResult Delete(int id)
        {
            try
            {
                empleados.rut_empleado = id;
                return Ok(empleadosBL.Delete(empleados));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        private List<EmpleadosDTO> convertList(List<Empleados> lista)
        {
            List<EmpleadosDTO> list = new List<EmpleadosDTO>();
            foreach (var item in lista)
            {
                EmpleadosDTO el = new EmpleadosDTO(item.rut_empleado, item.nombre_empleado, item.apellido_empleado, item.direccion, item.telefono);
                list.Add(el);

            }
            return list;

        }
        private EmpleadosDTO convert(Empleados item)
        {
            EmpleadosDTO obj = new EmpleadosDTO(item.rut_empleado, item.nombre_empleado, item.apellido_empleado, item.direccion, item.telefono);
            return obj;

        }
    }

}