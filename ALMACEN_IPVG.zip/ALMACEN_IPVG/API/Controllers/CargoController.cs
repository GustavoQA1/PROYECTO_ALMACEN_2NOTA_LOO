﻿using System;
using System.Reflection;
using API.Helper;
using Microsoft.AspNetCore.Mvc;
using Modelos.Mantenedores;
using Negocio.Mantenedores;

namespace API.Controllers
{
    [ApiController]
    public class CargoController: ControllerBase
    {
        CargoBL cargoBL = new CargoBL();
        Cargo cargo = new Cargo();
        ErrorResponse error;

        [HttpPost]
        [Route("v1/cargo/Create")]
        public ActionResult Create(CargoDTO o)
        {
            try
            {
                cargo.id_cargo = o.id_cargo;
                cargo.nombre_cargo = o.nombre_cargo;
                return Ok(cargoBL.Create(cargo));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/cargo/Get")]
        public ActionResult Get()
        {
            try
            {
                return Ok(convertList(cargoBL.Get(cargo)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpPost]
        [Route("v1/cargo/GetQuery")]
        public ActionResult GetQuery(string nombre)
        {
            try
            {
                cargo.nombre_cargo = nombre;
                return Ok(convertList(cargoBL.GetQuery(cargo)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/cargo/GetById")]
        public ActionResult GetById(int id)
        {
            try
            {
                cargo.id_cargo = id;
                cargo = cargoBL.GetById(cargo);
                if (cargo != null)
                    return Ok(convert(cargo));
                else
                    return StatusCode(404, cargo);
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }
        [HttpPut]
        [Route("v1/cargo/Update")]
        public ActionResult Update(CargoDTO o)
        {
            try
            {
                cargo.id_cargo = o.id_cargo;
                cargo.nombre_cargo = o.nombre_cargo;
                return Ok(cargoBL.Update(cargo));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpDelete]
        [Route("v1/cargo/Delete")]
        public ActionResult Delete(int id)
        {
            try
            {
                cargo.id_cargo = id;
                return Ok(cargoBL.Delete(cargo));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        private List<CargoDTO> convertList(List<Cargo> lista)
        {
            List<CargoDTO> list = new List<CargoDTO>();
            foreach (var item in lista)
            {
                CargoDTO el = new CargoDTO(item.id_cargo, item.nombre_cargo);
                list.Add(el);

            }
            return list;

        }
        private CargoDTO convert(Cargo item)
        {
            CargoDTO obj = new CargoDTO(item.id_cargo, item.nombre_cargo);
            return obj;

        }
    }

}

