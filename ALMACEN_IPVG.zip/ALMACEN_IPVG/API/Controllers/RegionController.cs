﻿using System;
using System.Reflection;
using API.Helper;
using Microsoft.AspNetCore.Mvc;
using Modelos.Mantenedores;
using Negocio.Mantenedores;

namespace API.Controllers
{
    [ApiController]
    public class RegionController : ControllerBase
    {
        RegionBL regionBL = new RegionBL();
        Region region = new Region();
        ErrorResponse error;

        [HttpPost]
        [Route("v1/region/Create")]
        public ActionResult Create(RegionDTO o)
        {
            try
            {
                region.id_region = o.id_region;
                region.nombre_region = o.nombre_region;
                return Ok(regionBL.Create(region));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/region/Get")]
        public ActionResult Get()
        {
            try
            {
                return Ok(convertList(regionBL.Get(region)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpPost]
        [Route("v1/region/GetQuery")]
        public ActionResult GetQuery(string nombre)
        {
            try
            {
                region.nombre_region = nombre;
                return Ok(convertList(regionBL.GetQuery(region)));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpGet]
        [Route("v1/region/GetById")]
        public ActionResult GetById(int id)
        {
            try
            {
                region.id_region = id;
                region = regionBL.GetById(region);
                if (region != null)
                    return Ok(convert(region));
                else
                    return StatusCode(404, region);
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }
        [HttpPut]
        [Route("v1/region/Update")]
        public ActionResult Update(RegionDTO o)
        {
            try
            {
                region.id_region = o.id_region;
                region.nombre_region = o.nombre_region;
                return Ok(regionBL.Update(region));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        [HttpDelete]
        [Route("v1/region/Delete")]
        public ActionResult Delete(int id)
        {
            try
            {
                region.id_region = id;
                return Ok(regionBL.Delete(region));
            }
            catch (Exception ex)
            {
                error = new ErrorResponse(ex);
                return StatusCode(500, error);
            }

        }

        private List<RegionDTO> convertList(List<Region> lista)
        {
            List<RegionDTO> list = new List<RegionDTO>();
            foreach (var item in lista)
            {
                RegionDTO el = new RegionDTO(item.id_region, item.nombre_region);
                list.Add(el);

            }
            return list;

        }
        private RegionDTO convert(Region item)
        {
            RegionDTO obj = new RegionDTO(item.id_region, item.nombre_region);
            return obj;

        }
    }

}